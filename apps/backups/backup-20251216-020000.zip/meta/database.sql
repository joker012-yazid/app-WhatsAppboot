--
-- PostgreSQL database dump
--

\restrict SwEUkJd1rhJZ5CxUaj5Np3jAvfjuWpbkr4a7CcS8R3mQb4bcBBsml59HG4yGjr3

-- Dumped from database version 17.6 (Debian 17.6-0+deb13u1)
-- Dumped by pg_dump version 17.6 (Debian 17.6-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- Name: CampaignKind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CampaignKind" AS ENUM (
    'PROMOTIONAL',
    'ANNOUNCEMENT',
    'FOLLOW_UP',
    'CUSTOM'
);


--
-- Name: CampaignRecipientStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CampaignRecipientStatus" AS ENUM (
    'PENDING',
    'SCHEDULED',
    'SKIPPED',
    'SENT',
    'DELIVERED',
    'FAILED',
    'CANCELLED'
);


--
-- Name: CampaignStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CampaignStatus" AS ENUM (
    'DRAFT',
    'SCHEDULED',
    'RUNNING',
    'PAUSED',
    'COMPLETED',
    'FAILED',
    'CANCELLED'
);


--
-- Name: CustomerType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CustomerType" AS ENUM (
    'VIP',
    'REGULAR',
    'NEW',
    'PROSPECT'
);


--
-- Name: JobPriority; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."JobPriority" AS ENUM (
    'LOW',
    'NORMAL',
    'HIGH',
    'URGENT'
);


--
-- Name: JobStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."JobStatus" AS ENUM (
    'AWAITING_QUOTE',
    'QUOTATION_SENT',
    'APPROVED',
    'CANCELLED',
    'REPAIRING',
    'COMPLETED'
);


--
-- Name: MessageDirection; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MessageDirection" AS ENUM (
    'INBOUND',
    'OUTBOUND'
);


--
-- Name: MessageRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MessageRole" AS ENUM (
    'SYSTEM',
    'USER',
    'ASSISTANT',
    'AGENT'
);


--
-- Name: MessageStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MessageStatus" AS ENUM (
    'SENT',
    'DELIVERED',
    'READ',
    'FAILED',
    'RECEIVED'
);


--
-- Name: ReminderKind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ReminderKind" AS ENUM (
    'QUOTE_DAY_1',
    'QUOTE_DAY_20',
    'QUOTE_DAY_30'
);


--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserRole" AS ENUM (
    'ADMIN',
    'USER'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AiConversation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AiConversation" (
    id text NOT NULL,
    "jobId" text,
    "customerId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: AiMessage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AiMessage" (
    id text NOT NULL,
    "conversationId" text NOT NULL,
    role public."MessageRole" NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Campaign; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Campaign" (
    id text NOT NULL,
    name text NOT NULL,
    kind public."CampaignKind" DEFAULT 'PROMOTIONAL'::public."CampaignKind" NOT NULL,
    status public."CampaignStatus" DEFAULT 'DRAFT'::public."CampaignStatus" NOT NULL,
    message text NOT NULL,
    "mediaUrl" text,
    variables text[] DEFAULT ARRAY[]::text[],
    filters jsonb,
    "scheduledFor" timestamp(3) without time zone,
    "startedAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "targetCount" integer DEFAULT 0 NOT NULL,
    "sentCount" integer DEFAULT 0 NOT NULL,
    "failedCount" integer DEFAULT 0 NOT NULL,
    "dailyLimit" integer DEFAULT 150 NOT NULL,
    "randomDelayMin" integer DEFAULT 30 NOT NULL,
    "randomDelayMax" integer DEFAULT 60 NOT NULL,
    "businessHoursStart" integer,
    "businessHoursEnd" integer,
    "createdById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: CampaignEvent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CampaignEvent" (
    id text NOT NULL,
    "campaignId" text NOT NULL,
    type text NOT NULL,
    details jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: CampaignPreset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CampaignPreset" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    filters jsonb NOT NULL,
    "createdById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: CampaignRecipient; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CampaignRecipient" (
    id text NOT NULL,
    "campaignId" text NOT NULL,
    "customerId" text,
    phone text NOT NULL,
    name text,
    status public."CampaignRecipientStatus" DEFAULT 'PENDING'::public."CampaignRecipientStatus" NOT NULL,
    error text,
    attempts integer DEFAULT 0 NOT NULL,
    "lastAttemptAt" timestamp(3) without time zone,
    "sentAt" timestamp(3) without time zone,
    "deliveredAt" timestamp(3) without time zone,
    "readAt" timestamp(3) without time zone,
    "respondedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Customer" (
    id text NOT NULL,
    name text NOT NULL,
    phone text NOT NULL,
    email text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    tags text[] DEFAULT ARRAY[]::text[],
    type public."CustomerType" DEFAULT 'REGULAR'::public."CustomerType" NOT NULL
);


--
-- Name: Device; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Device" (
    id text NOT NULL,
    "customerId" text NOT NULL,
    "deviceType" text NOT NULL,
    brand text,
    model text,
    "serialNumber" text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Job; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Job" (
    id text NOT NULL,
    "customerId" text NOT NULL,
    "deviceId" text NOT NULL,
    title text NOT NULL,
    description text,
    status public."JobStatus" DEFAULT 'AWAITING_QUOTE'::public."JobStatus" NOT NULL,
    priority public."JobPriority" DEFAULT 'NORMAL'::public."JobPriority" NOT NULL,
    "quotedAmount" numeric(65,30),
    "approvedAmount" numeric(65,30),
    diagnosis text,
    "dueDate" timestamp(3) without time zone,
    "qrToken" text NOT NULL,
    "qrExpiresAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "assignedAt" timestamp(3) without time zone,
    "ownerUserId" text
);


--
-- Name: JobMessage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."JobMessage" (
    id text NOT NULL,
    "jobId" text NOT NULL,
    role public."MessageRole" NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: JobPhoto; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."JobPhoto" (
    id text NOT NULL,
    "jobId" text NOT NULL,
    label text,
    "filePath" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: JobStatusHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."JobStatusHistory" (
    id text NOT NULL,
    "jobId" text NOT NULL,
    status public."JobStatus" NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Message" (
    id text NOT NULL,
    "customerId" text NOT NULL,
    direction public."MessageDirection" NOT NULL,
    content text NOT NULL,
    status public."MessageStatus" DEFAULT 'SENT'::public."MessageStatus" NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "receivedAt" timestamp(3) without time zone,
    "readAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: RefreshToken; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RefreshToken" (
    id text NOT NULL,
    "tokenHash" text NOT NULL,
    "userId" text NOT NULL,
    "sessionId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "revokedAt" timestamp(3) without time zone
);


--
-- Name: Reminder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Reminder" (
    id text NOT NULL,
    "jobId" text NOT NULL,
    kind public."ReminderKind" NOT NULL,
    "sentAt" timestamp(3) without time zone
);


--
-- Name: Session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "userAgent" text,
    "ipAddress" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "revokedAt" timestamp(3) without time zone
);


--
-- Name: SystemSetting; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SystemSetting" (
    id text NOT NULL,
    key text NOT NULL,
    "group" text,
    value jsonb NOT NULL,
    "updatedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    role public."UserRole" DEFAULT 'USER'::public."UserRole" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "approvedAt" timestamp(3) without time zone,
    "approvedBy" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastLoginAt" timestamp(3) without time zone,
    permissions jsonb,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    username text
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: AiConversation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AiConversation" (id, "jobId", "customerId", "createdAt") FROM stdin;
\.


--
-- Data for Name: AiMessage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AiMessage" (id, "conversationId", role, content, "createdAt") FROM stdin;
\.


--
-- Data for Name: Campaign; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Campaign" (id, name, kind, status, message, "mediaUrl", variables, filters, "scheduledFor", "startedAt", "completedAt", "targetCount", "sentCount", "failedCount", "dailyLimit", "randomDelayMin", "randomDelayMax", "businessHoursStart", "businessHoursEnd", "createdById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CampaignEvent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CampaignEvent" (id, "campaignId", type, details, "createdAt") FROM stdin;
\.


--
-- Data for Name: CampaignPreset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CampaignPreset" (id, name, description, filters, "createdById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CampaignRecipient; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CampaignRecipient" (id, "campaignId", "customerId", phone, name, status, error, attempts, "lastAttemptAt", "sentAt", "deliveredAt", "readAt", "respondedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Customer" (id, name, phone, email, notes, "createdAt", "updatedAt", tags, type) FROM stdin;
718e677f-4330-4624-8570-0c32c6247fec	Ali Ahmad	60110000001	ali@example.com	VIP	2025-12-15 08:53:33.707	2025-12-15 08:53:33.707	{}	REGULAR
633f2201-429b-4677-99fa-f4ce1a9c4f54	Siti Nor	60110000002	siti@example.com	\N	2025-12-15 08:53:33.709	2025-12-15 08:53:33.709	{}	REGULAR
11f8abbd-025a-45d1-a0e3-550dec9226fa	Rahman Co	60110000003	ops@rahmanco.my	Corporate	2025-12-15 08:53:33.712	2025-12-15 08:53:33.712	{}	REGULAR
d4f24cac-6b9a-483b-8754-10a88b0e0933	Farah Aziz	60110000004	\N	Prefers WhatsApp	2025-12-15 08:53:33.716	2025-12-15 08:53:33.716	{}	REGULAR
59f19e59-3be5-49ce-9eaf-c8b2fe995017	Daniel Tan	60110000005	daniel@example.com	\N	2025-12-15 08:53:33.719	2025-12-15 08:53:33.719	{}	REGULAR
326ce782-c036-4573-a8dc-7c6e9b0f19ea	Yazid	0163182443	yazidmohd058@gmail.com	\N	2025-12-15 08:59:05.817	2025-12-15 08:59:05.817	{WALK-IN,QR-REGISTERED}	REGULAR
\.


--
-- Data for Name: Device; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Device" (id, "customerId", "deviceType", brand, model, "serialNumber", notes, "createdAt", "updatedAt") FROM stdin;
62599ae7-79b9-4e31-b990-8b336942c02c	718e677f-4330-4624-8570-0c32c6247fec	Phone	Generic	Model X	\N	\N	2025-12-15 08:53:33.728	2025-12-15 08:53:33.728
5c727b89-b8d1-41dc-9326-c75613b58c3e	633f2201-429b-4677-99fa-f4ce1a9c4f54	Phone	Generic	Model X	\N	\N	2025-12-15 08:53:33.73	2025-12-15 08:53:33.73
86c1df5e-95ec-4e0a-b8e1-8a9a891ff173	326ce782-c036-4573-a8dc-7c6e9b0f19ea	laptop	Asus	ROG 5	\N	Tak boleh on dan keyboard rosak tit title	2025-12-15 08:59:05.82	2025-12-15 08:59:05.82
9da3b76b-8f90-489e-92ce-fb8e3ba84676	326ce782-c036-4573-a8dc-7c6e9b0f19ea	desktop	Acer	Expire 14	\N	PC tak on ada bau benda terbakar	2025-12-15 08:59:05.824	2025-12-15 08:59:05.824
6edba87d-9b05-4b4b-b9d3-1cf6a9ecd408	326ce782-c036-4573-a8dc-7c6e9b0f19ea	printer	HP	Laserjet 2009	\N	Tak tahi kertas dengan print tak cantik	2025-12-15 08:59:05.827	2025-12-15 08:59:05.827
588a56c1-0dfe-44b0-925f-4b9446a06b37	326ce782-c036-4573-a8dc-7c6e9b0f19ea	monitor	Hp	Gg14	\N	Tak menyala bila on kan AC	2025-12-15 08:59:05.83	2025-12-15 08:59:05.83
89582f1b-7cba-419f-98bc-ebf6bf88d66c	326ce782-c036-4573-a8dc-7c6e9b0f19ea	phone	Asus	ROG phone 5	\N	Bila main game cepat panas dan autoribut	2025-12-15 08:59:05.833	2025-12-15 08:59:05.833
\.


--
-- Data for Name: Job; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Job" (id, "customerId", "deviceId", title, description, status, priority, "quotedAmount", "approvedAmount", diagnosis, "dueDate", "qrToken", "qrExpiresAt", "createdAt", "updatedAt", "assignedAt", "ownerUserId") FROM stdin;
41362576-118f-4627-bfcb-60f17f5e8ce0	326ce782-c036-4573-a8dc-7c6e9b0f19ea	86c1df5e-95ec-4e0a-b8e1-8a9a891ff173	laptop Asus ROG 5 - Yazid	Tak boleh on dan keyboard rosak tit title	AWAITING_QUOTE	NORMAL	\N	\N	\N	\N	1ed6a95e-d3d6-438e-90af-6a25d1bda64d	2026-01-14 08:59:05.821	2025-12-15 08:59:05.822	2025-12-15 08:59:05.822	\N	\N
efe311a1-26d8-4b65-86ef-2b598cd2020c	326ce782-c036-4573-a8dc-7c6e9b0f19ea	9da3b76b-8f90-489e-92ce-fb8e3ba84676	desktop Acer Expire 14 - Yazid	PC tak on ada bau benda terbakar	AWAITING_QUOTE	NORMAL	\N	\N	\N	\N	f7563534-7ea2-48f6-aee5-2b9e3833d5a5	2026-01-14 08:59:05.825	2025-12-15 08:59:05.826	2025-12-15 08:59:05.826	\N	\N
72ac1407-f466-4e75-a9d1-a48cfdee30fa	326ce782-c036-4573-a8dc-7c6e9b0f19ea	6edba87d-9b05-4b4b-b9d3-1cf6a9ecd408	printer HP Laserjet 2009 - Yazid	Tak tahi kertas dengan print tak cantik	AWAITING_QUOTE	NORMAL	\N	\N	\N	\N	e925a6d6-2e35-40ec-aa1f-9f787c4c3466	2026-01-14 08:59:05.828	2025-12-15 08:59:05.829	2025-12-15 08:59:05.829	\N	\N
bc85c068-cc97-4c9e-976e-63be1e7eac61	326ce782-c036-4573-a8dc-7c6e9b0f19ea	588a56c1-0dfe-44b0-925f-4b9446a06b37	monitor Hp Gg14 - Yazid	Tak menyala bila on kan AC	APPROVED	NORMAL	\N	\N	\N	2025-12-15 13:49:00	576b4b7e-ac08-45b8-ad40-93f09161a2b4	2026-01-14 08:59:05.831	2025-12-15 08:59:05.831	2025-12-15 14:02:17.893	\N	\N
cedc72be-cc67-4140-8f38-65e11d581078	326ce782-c036-4573-a8dc-7c6e9b0f19ea	89582f1b-7cba-419f-98bc-ebf6bf88d66c	phone Asus ROG phone 5 - Yazid	Bila main game cepat panas dan autoribut	REPAIRING	NORMAL	\N	\N	\N	\N	2ca7e5f6-8ed1-4b86-9f20-72c2bb8ddd4e	2026-01-14 08:59:05.833	2025-12-15 08:59:05.834	2025-12-15 14:12:47.216	\N	\N
\.


--
-- Data for Name: JobMessage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."JobMessage" (id, "jobId", role, content, "createdAt") FROM stdin;
\.


--
-- Data for Name: JobPhoto; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."JobPhoto" (id, "jobId", label, "filePath", "createdAt") FROM stdin;
\.


--
-- Data for Name: JobStatusHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."JobStatusHistory" (id, "jobId", status, notes, "createdAt") FROM stdin;
fdcc1a98-7b9f-4d76-8427-ac6a7e9e36d0	bc85c068-cc97-4c9e-976e-63be1e7eac61	AWAITING_QUOTE	\N	2025-12-15 13:49:57.112
6212b5e8-aaf9-421b-9f86-4c0df6904068	bc85c068-cc97-4c9e-976e-63be1e7eac61	APPROVED	Status updated from AWAITING_QUOTE to APPROVED	2025-12-15 14:02:17.895
e2eb56bd-3cc2-4ffc-813f-ae76a5653dc0	cedc72be-cc67-4140-8f38-65e11d581078	REPAIRING	Status updated from APPROVED to REPAIRING	2025-12-15 14:12:47.219
\.


--
-- Data for Name: Message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Message" (id, "customerId", direction, content, status, "sentAt", "receivedAt", "readAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: RefreshToken; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RefreshToken" (id, "tokenHash", "userId", "sessionId", "createdAt", "expiresAt", "revokedAt") FROM stdin;
61869399-621f-4644-ae4f-3dae79ae78d7	$2a$10$xNkJQTSKfUg6R5aMkMurg.GJoHLMbwzSKM3bKyCil2rrLUmmxQGQW	52725896-96e2-439b-bee9-4297a5fc72bf	d92735ae-086d-4c1d-ad2c-8a6576c8997c	2025-12-15 08:55:06.918	2025-12-22 08:55:06.917	2025-12-15 09:00:41.985
47539218-ff40-4673-8e05-f6a62e0d0364	$2a$10$k2hWNNWNxd1yQMcB15F9JephrPNoG13pelYWFrxOHvk95RUQPumGi	52725896-96e2-439b-bee9-4297a5fc72bf	2a2e0d36-260e-4385-a4ec-8c6ee0bbdced	2025-12-15 09:00:51.666	2025-12-22 09:00:51.665	2025-12-15 09:06:02.037
16aba310-75a4-40d2-b188-44b8858b1b51	$2a$10$lU4VF6UX5XR5nZAeHqKapez/iry/zABsA93zPKwBcIIHiKANHP/6K	52725896-96e2-439b-bee9-4297a5fc72bf	6cdfe710-87c8-435d-b0dc-d69f6704fdae	2025-12-15 09:08:50.463	2025-12-22 09:08:50.462	2025-12-15 09:38:56.523
6ddcc380-2c83-4a87-9ea1-1f5c1b50a549	$2a$10$FeRWbhP43DuN5EvZIJU12OUdpgjclkg.seIACxBcP6Qd4fl.CDlDG	52725896-96e2-439b-bee9-4297a5fc72bf	27bbd443-66e7-4acc-be7c-4ddf2530cb00	2025-12-15 09:39:02.964	2025-12-22 09:39:02.963	2025-12-15 09:41:03.125
385c3cbb-abf1-45ba-8bd5-621c763adf3b	$2a$10$6YqdB0WzjUhJIV2ra18iguiiLT55qG.NZpyUVlFWBhF.ciBoCGZaS	52725896-96e2-439b-bee9-4297a5fc72bf	114dd234-2957-4a6a-9d66-9269bf3505f0	2025-12-15 10:38:30.879	2025-12-22 10:38:30.878	2025-12-15 11:20:47.85
4a4a09d8-00c3-4f14-82de-0aa82e04a867	$2a$10$VXyRYhZ/IYUraP5TSUNqpOJnPU27OcZHI9EbmCBBRZcelSajQXvo6	52725896-96e2-439b-bee9-4297a5fc72bf	69442333-b1b9-4de1-8789-5194c7a0fd8e	2025-12-15 11:23:24.195	2025-12-22 11:23:24.194	2025-12-15 11:25:18.168
4aaf9bcb-2290-4357-991a-859fdcc2d92e	$2a$10$iw8MEk757P8GflvluHrTo.Hd3yKn.E8H.9x0mUGUf1pYiRb/vXp6W	52725896-96e2-439b-bee9-4297a5fc72bf	58d80f50-824b-40e0-80f2-a78e413c1f47	2025-12-15 11:26:11.528	2025-12-22 11:26:11.527	2025-12-15 11:29:43.164
67455135-84b9-434b-a319-5065f7e3ca4e	$2a$10$eAIUnHnqgH6IuTNIJ0XiKOlTLIoLgZX0Q3gzKC7nVZ/YtXNEnzW26	52725896-96e2-439b-bee9-4297a5fc72bf	5590cbd5-f56d-4ac3-8682-19061e1742a7	2025-12-15 11:29:55.121	2025-12-22 11:29:55.12	2025-12-15 11:30:51.886
14cc7ede-d00b-469e-a60c-76143aedd2bf	$2a$10$aN1nHG3RaOmGfLI/NHYe9.ANqhLLwLdWaxUc9o3.xJng3wJBqbjIq	838f3525-5a83-4dc3-bdf8-cf54b8ba23dd	b6ca86f5-078c-490a-8762-ae08c4c42292	2025-12-15 11:31:16.389	2025-12-22 11:31:16.388	2025-12-15 11:32:35.283
2c740b3f-366c-4102-bbd2-1322c8185582	$2a$10$GakSLEQDsUnTfeQqzXCBzOy56tbWW.SstSGz7g8eNZXGwwk63d.0i	838f3525-5a83-4dc3-bdf8-cf54b8ba23dd	2e0cb0ec-84b1-4512-aa20-20e9374353b2	2025-12-15 11:32:49.67	2025-12-22 11:32:49.67	2025-12-15 11:37:03.138
82bbcbed-fd35-49ba-b41c-e927cf816df5	$2a$10$D.2zbJWVZDkaSAsQygXG7OnPV8D0RRoV4saG5RCWfJ0j90ui1ZQz2	52725896-96e2-439b-bee9-4297a5fc72bf	3dd6cfc6-9788-4104-99f6-8e76055cf315	2025-12-15 11:37:28.652	2025-12-22 11:37:28.652	2025-12-15 11:38:00.293
e46d4b83-2131-4f54-885f-76c06af529bc	$2a$10$c8Xphs3tBQz2fOKInQYd/uJJpqxbOY1InvR7/rTqe7jGA5R9z78DS	52725896-96e2-439b-bee9-4297a5fc72bf	9d7e7089-06d9-4469-b78b-bf3d0069e0de	2025-12-15 11:39:29.055	2025-12-22 11:39:29.054	2025-12-15 11:42:17.528
3ba4c9cf-87f7-42f4-9eac-7cedce028b03	$2a$10$yzD.9fWseX.lgI.NjvpCHehSxU7EGOt9sUMyucRj37ViB4U9VK3dm	52725896-96e2-439b-bee9-4297a5fc72bf	1f644189-8dce-47f0-8703-d0fb82d6c409	2025-12-15 11:45:58.456	2025-12-22 11:45:58.455	\N
d6791c45-c615-4dfe-9d1e-2349fcc36bbf	$2a$10$oCOhCzGqLZaJ3AtJvr73tetXf1P7lhR9APGu/ym7swpTPMkOJ917e	52725896-96e2-439b-bee9-4297a5fc72bf	9d837f67-68f8-44ac-aa05-43680a9835d7	2025-12-15 13:34:16.039	2025-12-22 13:34:16.038	2025-12-15 13:36:12.821
f3aa23e0-3d03-48f4-a6f7-3a194d0a47a1	$2a$10$VeAyyaAfpo5V5/nutKYfO.Q3ZQGhGPGvpeyOxjAdddOEOn3KLTFkK	52725896-96e2-439b-bee9-4297a5fc72bf	fe678f0b-8c2d-49d5-be9a-833ade3ee451	2025-12-15 13:36:27.617	2025-12-22 13:36:27.616	2025-12-15 13:37:01.897
8ce52a5f-1724-412a-8c93-04ca2f10f0e4	$2a$10$YTyxicRMNi/soNTkBMCi4OAY1RB5liVSE4AGV33eTnjTxQEfgWmjC	838f3525-5a83-4dc3-bdf8-cf54b8ba23dd	b2f5fde5-6f6a-426f-9c02-935f4ca74090	2025-12-15 13:37:17.053	2025-12-22 13:37:17.052	2025-12-15 13:47:12.784
2a5cf0b5-1e4b-451b-892e-60682b12d5d6	$2a$10$Uep13pLylyXY0s7AzcTQkufisgk.tO9ukVp6dD9BFeUXwhhWrela6	52725896-96e2-439b-bee9-4297a5fc72bf	52c834a1-f8d3-45d2-9e06-673746330d22	2025-12-15 13:47:27.37	2025-12-22 13:47:27.369	2025-12-15 13:48:15.366
aa065651-0c8c-4f04-a0c0-5646dd098325	$2a$10$sWFg2YXITWz69fenSn4usOZ7OT993f96gcFAirW.42hK2qqmBxCYC	838f3525-5a83-4dc3-bdf8-cf54b8ba23dd	dfe4aca2-6ce9-4493-80ba-4f7becdc7ba1	2025-12-15 13:48:32.354	2025-12-22 13:48:32.353	2025-12-15 14:03:10.065
b0810f50-3bdd-486e-9bd1-5b6286c28ddf	$2a$10$NmuCIggSOiXDzkHNs529J.j43wZt7eAb9lrhXXzZJY8qK4OjPWeKy	52725896-96e2-439b-bee9-4297a5fc72bf	c74263a3-5c42-42eb-99c0-6ae64495538a	2025-12-15 14:03:35.571	2025-12-22 14:03:35.57	2025-12-15 14:12:13.873
8a0875b9-4307-4d4d-88df-8d26b90e0cca	$2a$10$grfbOMcvgBUSYPWTwy8D4eUto4lEZhfBzLjLys.FWBWqAJVuH94IS	838f3525-5a83-4dc3-bdf8-cf54b8ba23dd	e1906aea-d086-4ea5-8f0c-f6668db30614	2025-12-15 14:12:31.431	2025-12-22 14:12:31.43	\N
\.


--
-- Data for Name: Reminder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Reminder" (id, "jobId", kind, "sentAt") FROM stdin;
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Session" (id, "userId", "userAgent", "ipAddress", "createdAt", "expiresAt", "revokedAt") FROM stdin;
d92735ae-086d-4c1d-ad2c-8a6576c8997c	52725896-96e2-439b-bee9-4297a5fc72bf	\N	\N	2025-12-15 08:55:06.813	2025-12-22 08:55:06.812	2025-12-15 09:00:41.983
2a2e0d36-260e-4385-a4ec-8c6ee0bbdced	52725896-96e2-439b-bee9-4297a5fc72bf	\N	\N	2025-12-15 09:00:51.566	2025-12-22 09:00:51.565	2025-12-15 09:06:02.036
6cdfe710-87c8-435d-b0dc-d69f6704fdae	52725896-96e2-439b-bee9-4297a5fc72bf	\N	\N	2025-12-15 09:08:50.358	2025-12-22 09:08:50.357	2025-12-15 09:38:56.521
27bbd443-66e7-4acc-be7c-4ddf2530cb00	52725896-96e2-439b-bee9-4297a5fc72bf	\N	\N	2025-12-15 09:39:02.86	2025-12-22 09:39:02.859	2025-12-15 09:41:03.123
114dd234-2957-4a6a-9d66-9269bf3505f0	52725896-96e2-439b-bee9-4297a5fc72bf	\N	\N	2025-12-15 10:38:30.774	2025-12-22 10:38:30.772	2025-12-15 11:20:47.847
69442333-b1b9-4de1-8789-5194c7a0fd8e	52725896-96e2-439b-bee9-4297a5fc72bf	\N	\N	2025-12-15 11:23:24.087	2025-12-22 11:23:24.086	2025-12-15 11:25:18.166
58d80f50-824b-40e0-80f2-a78e413c1f47	52725896-96e2-439b-bee9-4297a5fc72bf	\N	\N	2025-12-15 11:26:11.423	2025-12-22 11:26:11.422	2025-12-15 11:29:43.16
5590cbd5-f56d-4ac3-8682-19061e1742a7	52725896-96e2-439b-bee9-4297a5fc72bf	\N	\N	2025-12-15 11:29:55.008	2025-12-22 11:29:55.007	2025-12-15 11:30:51.883
b6ca86f5-078c-490a-8762-ae08c4c42292	838f3525-5a83-4dc3-bdf8-cf54b8ba23dd	\N	\N	2025-12-15 11:31:16.281	2025-12-22 11:31:16.28	2025-12-15 11:32:35.281
2e0cb0ec-84b1-4512-aa20-20e9374353b2	838f3525-5a83-4dc3-bdf8-cf54b8ba23dd	\N	\N	2025-12-15 11:32:49.562	2025-12-22 11:32:49.561	2025-12-15 11:37:03.135
3dd6cfc6-9788-4104-99f6-8e76055cf315	52725896-96e2-439b-bee9-4297a5fc72bf	\N	\N	2025-12-15 11:37:28.541	2025-12-22 11:37:28.54	2025-12-15 11:38:00.291
9d7e7089-06d9-4469-b78b-bf3d0069e0de	52725896-96e2-439b-bee9-4297a5fc72bf	\N	\N	2025-12-15 11:39:28.952	2025-12-22 11:39:28.951	2025-12-15 11:42:17.526
1f644189-8dce-47f0-8703-d0fb82d6c409	52725896-96e2-439b-bee9-4297a5fc72bf	\N	\N	2025-12-15 11:45:58.349	2025-12-22 11:45:58.348	\N
9d837f67-68f8-44ac-aa05-43680a9835d7	52725896-96e2-439b-bee9-4297a5fc72bf	\N	\N	2025-12-15 13:34:15.9	2025-12-22 13:34:15.898	2025-12-15 13:36:12.815
fe678f0b-8c2d-49d5-be9a-833ade3ee451	52725896-96e2-439b-bee9-4297a5fc72bf	\N	\N	2025-12-15 13:36:27.484	2025-12-22 13:36:27.484	2025-12-15 13:37:01.895
b2f5fde5-6f6a-426f-9c02-935f4ca74090	838f3525-5a83-4dc3-bdf8-cf54b8ba23dd	\N	\N	2025-12-15 13:37:16.953	2025-12-22 13:37:16.952	2025-12-15 13:47:12.766
52c834a1-f8d3-45d2-9e06-673746330d22	52725896-96e2-439b-bee9-4297a5fc72bf	\N	\N	2025-12-15 13:47:27.159	2025-12-22 13:47:27.158	2025-12-15 13:48:15.362
dfe4aca2-6ce9-4493-80ba-4f7becdc7ba1	838f3525-5a83-4dc3-bdf8-cf54b8ba23dd	\N	\N	2025-12-15 13:48:32.246	2025-12-22 13:48:32.245	2025-12-15 14:03:10.063
c74263a3-5c42-42eb-99c0-6ae64495538a	52725896-96e2-439b-bee9-4297a5fc72bf	\N	\N	2025-12-15 14:03:35.3	2025-12-22 14:03:35.299	2025-12-15 14:12:13.871
e1906aea-d086-4ea5-8f0c-f6668db30614	838f3525-5a83-4dc3-bdf8-cf54b8ba23dd	\N	\N	2025-12-15 14:12:31.321	2025-12-22 14:12:31.32	\N
\.


--
-- Data for Name: SystemSetting; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SystemSetting" (id, key, "group", value, "updatedById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, name, email, "passwordHash", role, "createdAt", "updatedAt", "approvedAt", "approvedBy", "isActive", "lastLoginAt", permissions, status, username) FROM stdin;
52725896-96e2-439b-bee9-4297a5fc72bf	Admin	admin@example.com	$2a$10$lxqhXyzf1G9gfUpZp6pdHO2heVyue/QEf.a1a2vK1tIC.7neFswq6	ADMIN	2025-12-15 08:53:33.699	2025-12-15 08:53:33.699	\N	\N	t	\N	\N	ACTIVE	\N
838f3525-5a83-4dc3-bdf8-cf54b8ba23dd	mohd noryazid	yazidmohd058@gmail.com	$2a$10$w7LPXs2QRHDwOTf2pVQqm..wrHY9.I0pib9dK7IXZn/wgjkVDoxP6	USER	2025-12-15 11:30:41.595	2025-12-15 11:30:41.595	2025-12-15 11:30:41.594	\N	t	\N	\N	ACTIVE	yazid
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
141a1685-d678-4144-9a08-115f4966af5a	841df6f8e27762f8ffb9bc850b058301a8124559407ef75a99445d5fe6f7dad1	2025-12-15 16:28:31.246216+08	20251126071209_whats_appbot	\N	\N	2025-12-15 16:28:31.222099+08	1
8cc2c2f6-25ac-47f5-a632-cac405f82339	b2abf5242016dce6bf3d6a4a71a5a61617e11b644be8635b995e7e86608e3248	2025-12-15 16:28:31.259546+08	20251126081020_add_campaigns_and_settings	\N	\N	2025-12-15 16:28:31.246839+08	1
cef35f04-a104-4965-85a3-df60e554d34e	cdcc99f277ee51be1e2a1fc6359ca361fe07d7be5fdf1c84e437b6115e84aeae	2025-12-15 16:28:31.265701+08	20251213082532_	\N	\N	2025-12-15 16:28:31.260292+08	1
a3a6095f-032a-4008-a46c-c5df70866748	f3fa6219bbac4fc0df29c917b68c43ef4b10205e131bafaf050c4d514c66f0f6	2025-12-15 16:28:31.268173+08	20251215141922_add_job_ownership	\N	\N	2025-12-15 16:28:31.266443+08	1
\.


--
-- Name: AiConversation AiConversation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AiConversation"
    ADD CONSTRAINT "AiConversation_pkey" PRIMARY KEY (id);


--
-- Name: AiMessage AiMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AiMessage"
    ADD CONSTRAINT "AiMessage_pkey" PRIMARY KEY (id);


--
-- Name: CampaignEvent CampaignEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignEvent"
    ADD CONSTRAINT "CampaignEvent_pkey" PRIMARY KEY (id);


--
-- Name: CampaignPreset CampaignPreset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignPreset"
    ADD CONSTRAINT "CampaignPreset_pkey" PRIMARY KEY (id);


--
-- Name: CampaignRecipient CampaignRecipient_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignRecipient"
    ADD CONSTRAINT "CampaignRecipient_pkey" PRIMARY KEY (id);


--
-- Name: Campaign Campaign_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Campaign"
    ADD CONSTRAINT "Campaign_pkey" PRIMARY KEY (id);


--
-- Name: Customer Customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Customer"
    ADD CONSTRAINT "Customer_pkey" PRIMARY KEY (id);


--
-- Name: Device Device_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Device"
    ADD CONSTRAINT "Device_pkey" PRIMARY KEY (id);


--
-- Name: JobMessage JobMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobMessage"
    ADD CONSTRAINT "JobMessage_pkey" PRIMARY KEY (id);


--
-- Name: JobPhoto JobPhoto_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobPhoto"
    ADD CONSTRAINT "JobPhoto_pkey" PRIMARY KEY (id);


--
-- Name: JobStatusHistory JobStatusHistory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobStatusHistory"
    ADD CONSTRAINT "JobStatusHistory_pkey" PRIMARY KEY (id);


--
-- Name: Job Job_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Job"
    ADD CONSTRAINT "Job_pkey" PRIMARY KEY (id);


--
-- Name: Message Message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_pkey" PRIMARY KEY (id);


--
-- Name: RefreshToken RefreshToken_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_pkey" PRIMARY KEY (id);


--
-- Name: Reminder Reminder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Reminder"
    ADD CONSTRAINT "Reminder_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: SystemSetting SystemSetting_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SystemSetting"
    ADD CONSTRAINT "SystemSetting_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: CampaignRecipient_campaignId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "CampaignRecipient_campaignId_createdAt_idx" ON public."CampaignRecipient" USING btree ("campaignId", "createdAt");


--
-- Name: CampaignRecipient_campaignId_phone_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "CampaignRecipient_campaignId_phone_idx" ON public."CampaignRecipient" USING btree ("campaignId", phone);


--
-- Name: CampaignRecipient_campaignId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "CampaignRecipient_campaignId_status_idx" ON public."CampaignRecipient" USING btree ("campaignId", status);


--
-- Name: Campaign_status_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Campaign_status_createdAt_idx" ON public."Campaign" USING btree (status, "createdAt");


--
-- Name: Customer_phone_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Customer_phone_key" ON public."Customer" USING btree (phone);


--
-- Name: Job_qrToken_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Job_qrToken_key" ON public."Job" USING btree ("qrToken");


--
-- Name: Message_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Message_createdAt_idx" ON public."Message" USING btree ("createdAt");


--
-- Name: Message_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Message_customerId_idx" ON public."Message" USING btree ("customerId");


--
-- Name: RefreshToken_tokenHash_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "RefreshToken_tokenHash_key" ON public."RefreshToken" USING btree ("tokenHash");


--
-- Name: Reminder_jobId_kind_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Reminder_jobId_kind_idx" ON public."Reminder" USING btree ("jobId", kind);


--
-- Name: SystemSetting_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "SystemSetting_key_key" ON public."SystemSetting" USING btree (key);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "User_isActive_idx" ON public."User" USING btree ("isActive");


--
-- Name: User_role_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "User_role_idx" ON public."User" USING btree (role);


--
-- Name: User_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "User_status_idx" ON public."User" USING btree (status);


--
-- Name: User_username_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_username_key" ON public."User" USING btree (username);


--
-- Name: AiMessage AiMessage_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AiMessage"
    ADD CONSTRAINT "AiMessage_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."AiConversation"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CampaignEvent CampaignEvent_campaignId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignEvent"
    ADD CONSTRAINT "CampaignEvent_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES public."Campaign"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CampaignPreset CampaignPreset_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignPreset"
    ADD CONSTRAINT "CampaignPreset_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CampaignRecipient CampaignRecipient_campaignId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignRecipient"
    ADD CONSTRAINT "CampaignRecipient_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES public."Campaign"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CampaignRecipient CampaignRecipient_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignRecipient"
    ADD CONSTRAINT "CampaignRecipient_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Campaign Campaign_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Campaign"
    ADD CONSTRAINT "Campaign_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Device Device_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Device"
    ADD CONSTRAINT "Device_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: JobMessage JobMessage_jobId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobMessage"
    ADD CONSTRAINT "JobMessage_jobId_fkey" FOREIGN KEY ("jobId") REFERENCES public."Job"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: JobPhoto JobPhoto_jobId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobPhoto"
    ADD CONSTRAINT "JobPhoto_jobId_fkey" FOREIGN KEY ("jobId") REFERENCES public."Job"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: JobStatusHistory JobStatusHistory_jobId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobStatusHistory"
    ADD CONSTRAINT "JobStatusHistory_jobId_fkey" FOREIGN KEY ("jobId") REFERENCES public."Job"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Job Job_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Job"
    ADD CONSTRAINT "Job_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Job Job_deviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Job"
    ADD CONSTRAINT "Job_deviceId_fkey" FOREIGN KEY ("deviceId") REFERENCES public."Device"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Job Job_ownerUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Job"
    ADD CONSTRAINT "Job_ownerUserId_fkey" FOREIGN KEY ("ownerUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Message Message_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RefreshToken RefreshToken_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public."Session"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RefreshToken RefreshToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Reminder Reminder_jobId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Reminder"
    ADD CONSTRAINT "Reminder_jobId_fkey" FOREIGN KEY ("jobId") REFERENCES public."Job"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SystemSetting SystemSetting_updatedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SystemSetting"
    ADD CONSTRAINT "SystemSetting_updatedById_fkey" FOREIGN KEY ("updatedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict SwEUkJd1rhJZ5CxUaj5Np3jAvfjuWpbkr4a7CcS8R3mQb4bcBBsml59HG4yGjr3

