--
-- PostgreSQL database dump
--

\restrict eb6NW7fqJc8c89LUZtjjCQZazVm5GfS5BBYO82D5Dqpok9TFq6BwcnrcsBvUXri

-- Dumped from database version 17.6 (Debian 17.6-0+deb13u1)
-- Dumped by pg_dump version 17.6 (Debian 17.6-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- Name: CampaignKind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CampaignKind" AS ENUM (
    'PROMOTIONAL',
    'ANNOUNCEMENT',
    'FOLLOW_UP',
    'CUSTOM'
);


--
-- Name: CampaignRecipientStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CampaignRecipientStatus" AS ENUM (
    'PENDING',
    'SCHEDULED',
    'SKIPPED',
    'SENT',
    'DELIVERED',
    'FAILED',
    'CANCELLED'
);


--
-- Name: CampaignStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CampaignStatus" AS ENUM (
    'DRAFT',
    'SCHEDULED',
    'RUNNING',
    'PAUSED',
    'COMPLETED',
    'FAILED',
    'CANCELLED'
);


--
-- Name: CustomerType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CustomerType" AS ENUM (
    'VIP',
    'REGULAR',
    'NEW',
    'PROSPECT'
);


--
-- Name: JobPriority; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."JobPriority" AS ENUM (
    'LOW',
    'NORMAL',
    'HIGH',
    'URGENT'
);


--
-- Name: JobStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."JobStatus" AS ENUM (
    'AWAITING_QUOTE',
    'QUOTATION_SENT',
    'APPROVED',
    'CANCELLED',
    'REPAIRING',
    'COMPLETED'
);


--
-- Name: MessageDirection; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MessageDirection" AS ENUM (
    'INBOUND',
    'OUTBOUND'
);


--
-- Name: MessageRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MessageRole" AS ENUM (
    'SYSTEM',
    'USER',
    'ASSISTANT',
    'AGENT'
);


--
-- Name: MessageStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MessageStatus" AS ENUM (
    'SENT',
    'DELIVERED',
    'READ',
    'FAILED',
    'RECEIVED'
);


--
-- Name: ReminderKind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ReminderKind" AS ENUM (
    'QUOTE_DAY_1',
    'QUOTE_DAY_20',
    'QUOTE_DAY_30'
);


--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserRole" AS ENUM (
    'ADMIN',
    'USER'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AiConversation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AiConversation" (
    id text NOT NULL,
    "jobId" text,
    "customerId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: AiMessage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AiMessage" (
    id text NOT NULL,
    "conversationId" text NOT NULL,
    role public."MessageRole" NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Campaign; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Campaign" (
    id text NOT NULL,
    name text NOT NULL,
    kind public."CampaignKind" DEFAULT 'PROMOTIONAL'::public."CampaignKind" NOT NULL,
    status public."CampaignStatus" DEFAULT 'DRAFT'::public."CampaignStatus" NOT NULL,
    message text NOT NULL,
    "mediaUrl" text,
    variables text[] DEFAULT ARRAY[]::text[],
    filters jsonb,
    "scheduledFor" timestamp(3) without time zone,
    "startedAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "targetCount" integer DEFAULT 0 NOT NULL,
    "sentCount" integer DEFAULT 0 NOT NULL,
    "failedCount" integer DEFAULT 0 NOT NULL,
    "dailyLimit" integer DEFAULT 150 NOT NULL,
    "randomDelayMin" integer DEFAULT 30 NOT NULL,
    "randomDelayMax" integer DEFAULT 60 NOT NULL,
    "businessHoursStart" integer,
    "businessHoursEnd" integer,
    "createdById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: CampaignEvent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CampaignEvent" (
    id text NOT NULL,
    "campaignId" text NOT NULL,
    type text NOT NULL,
    details jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: CampaignPreset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CampaignPreset" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    filters jsonb NOT NULL,
    "createdById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: CampaignRecipient; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CampaignRecipient" (
    id text NOT NULL,
    "campaignId" text NOT NULL,
    "customerId" text,
    phone text NOT NULL,
    name text,
    status public."CampaignRecipientStatus" DEFAULT 'PENDING'::public."CampaignRecipientStatus" NOT NULL,
    error text,
    attempts integer DEFAULT 0 NOT NULL,
    "lastAttemptAt" timestamp(3) without time zone,
    "sentAt" timestamp(3) without time zone,
    "deliveredAt" timestamp(3) without time zone,
    "readAt" timestamp(3) without time zone,
    "respondedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Customer" (
    id text NOT NULL,
    name text NOT NULL,
    phone text NOT NULL,
    email text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    tags text[] DEFAULT ARRAY[]::text[],
    type public."CustomerType" DEFAULT 'REGULAR'::public."CustomerType" NOT NULL
);


--
-- Name: DeletedUserAudit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DeletedUserAudit" (
    id text NOT NULL,
    "originalUserId" text NOT NULL,
    username text,
    email text,
    name text,
    role public."UserRole",
    status text,
    "deletedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "deletedById" text NOT NULL,
    reason text,
    "ownedJobsCount" integer DEFAULT 0 NOT NULL,
    "campaignsCount" integer DEFAULT 0 NOT NULL,
    "dataSnapshot" jsonb
);


--
-- Name: Device; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Device" (
    id text NOT NULL,
    "customerId" text NOT NULL,
    "deviceType" text NOT NULL,
    brand text,
    model text,
    "serialNumber" text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Job; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Job" (
    id text NOT NULL,
    "customerId" text NOT NULL,
    "deviceId" text NOT NULL,
    title text NOT NULL,
    description text,
    status public."JobStatus" DEFAULT 'AWAITING_QUOTE'::public."JobStatus" NOT NULL,
    priority public."JobPriority" DEFAULT 'NORMAL'::public."JobPriority" NOT NULL,
    "quotedAmount" numeric(65,30),
    "approvedAmount" numeric(65,30),
    diagnosis text,
    "dueDate" timestamp(3) without time zone,
    "qrToken" text NOT NULL,
    "qrExpiresAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "assignedAt" timestamp(3) without time zone,
    "ownerUserId" text
);


--
-- Name: JobMessage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."JobMessage" (
    id text NOT NULL,
    "jobId" text NOT NULL,
    role public."MessageRole" NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: JobPhoto; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."JobPhoto" (
    id text NOT NULL,
    "jobId" text NOT NULL,
    label text,
    "filePath" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: JobStatusHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."JobStatusHistory" (
    id text NOT NULL,
    "jobId" text NOT NULL,
    status public."JobStatus" NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Message" (
    id text NOT NULL,
    "customerId" text NOT NULL,
    direction public."MessageDirection" NOT NULL,
    content text NOT NULL,
    status public."MessageStatus" DEFAULT 'SENT'::public."MessageStatus" NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "receivedAt" timestamp(3) without time zone,
    "readAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: RefreshToken; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RefreshToken" (
    id text NOT NULL,
    "tokenHash" text NOT NULL,
    "userId" text NOT NULL,
    "sessionId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "revokedAt" timestamp(3) without time zone
);


--
-- Name: Reminder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Reminder" (
    id text NOT NULL,
    "jobId" text NOT NULL,
    kind public."ReminderKind" NOT NULL,
    "sentAt" timestamp(3) without time zone
);


--
-- Name: Session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "userAgent" text,
    "ipAddress" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "revokedAt" timestamp(3) without time zone
);


--
-- Name: SystemSetting; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SystemSetting" (
    id text NOT NULL,
    key text NOT NULL,
    "group" text,
    value jsonb NOT NULL,
    "updatedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    role public."UserRole" DEFAULT 'USER'::public."UserRole" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "approvedAt" timestamp(3) without time zone,
    "approvedBy" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastLoginAt" timestamp(3) without time zone,
    permissions jsonb,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    username text
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: AiConversation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AiConversation" (id, "jobId", "customerId", "createdAt") FROM stdin;
\.


--
-- Data for Name: AiMessage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AiMessage" (id, "conversationId", role, content, "createdAt") FROM stdin;
\.


--
-- Data for Name: Campaign; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Campaign" (id, name, kind, status, message, "mediaUrl", variables, filters, "scheduledFor", "startedAt", "completedAt", "targetCount", "sentCount", "failedCount", "dailyLimit", "randomDelayMin", "randomDelayMax", "businessHoursStart", "businessHoursEnd", "createdById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CampaignEvent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CampaignEvent" (id, "campaignId", type, details, "createdAt") FROM stdin;
\.


--
-- Data for Name: CampaignPreset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CampaignPreset" (id, name, description, filters, "createdById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CampaignRecipient; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CampaignRecipient" (id, "campaignId", "customerId", phone, name, status, error, attempts, "lastAttemptAt", "sentAt", "deliveredAt", "readAt", "respondedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Customer" (id, name, phone, email, notes, "createdAt", "updatedAt", tags, type) FROM stdin;
718e677f-4330-4624-8570-0c32c6247fec	Ali Ahmad	60110000001	ali@example.com	VIP	2025-12-15 08:53:33.707	2025-12-15 08:53:33.707	{}	REGULAR
633f2201-429b-4677-99fa-f4ce1a9c4f54	Siti Nor	60110000002	siti@example.com	\N	2025-12-15 08:53:33.709	2025-12-15 08:53:33.709	{}	REGULAR
11f8abbd-025a-45d1-a0e3-550dec9226fa	Rahman Co	60110000003	ops@rahmanco.my	Corporate	2025-12-15 08:53:33.712	2025-12-15 08:53:33.712	{}	REGULAR
d4f24cac-6b9a-483b-8754-10a88b0e0933	Farah Aziz	60110000004	\N	Prefers WhatsApp	2025-12-15 08:53:33.716	2025-12-15 08:53:33.716	{}	REGULAR
59f19e59-3be5-49ce-9eaf-c8b2fe995017	Daniel Tan	60110000005	daniel@example.com	\N	2025-12-15 08:53:33.719	2025-12-15 08:53:33.719	{}	REGULAR
326ce782-c036-4573-a8dc-7c6e9b0f19ea	Yazid	0163182443	yazidmohd058@gmail.com	\N	2025-12-15 08:59:05.817	2025-12-15 08:59:05.817	{WALK-IN,QR-REGISTERED}	REGULAR
\.


--
-- Data for Name: DeletedUserAudit; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."DeletedUserAudit" (id, "originalUserId", username, email, name, role, status, "deletedAt", "deletedById", reason, "ownedJobsCount", "campaignsCount", "dataSnapshot") FROM stdin;
bc7267c4-1158-43fe-9306-de67353dec05	eee2c5af-ce90-43f0-993d-e1b6dbdb54fa	testuser	test@user.com	Test User	USER	ACTIVE	2025-12-16 14:04:42.533	6225f1a1-3c8a-4d83-81b3-f5ee7c56de38	Testing hard delete functionality	0	0	{"isActive": true, "createdAt": "2025-12-16T14:04:24.341Z", "lastLoginAt": null}
0eaabfd8-d48e-4440-89be-153e5531ac67	52725896-96e2-439b-bee9-4297a5fc72bf	\N	test@example.com	Test User	USER	INACTIVE	2025-12-16 14:07:12.666	6225f1a1-3c8a-4d83-81b3-f5ee7c56de38	yes	0	0	{"isActive": false, "createdAt": "2025-12-15T08:53:33.699Z", "lastLoginAt": null}
31db261e-2b3d-4ca3-8a2a-51a4a74e4c9d	838f3525-5a83-4dc3-bdf8-cf54b8ba23dd	yazid	yazidmohd058@gmail.com	mohd noryazid	USER	INACTIVE	2025-12-16 14:07:29.406	6225f1a1-3c8a-4d83-81b3-f5ee7c56de38	yes	0	0	{"isActive": false, "createdAt": "2025-12-15T11:30:41.595Z", "lastLoginAt": null}
\.


--
-- Data for Name: Device; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Device" (id, "customerId", "deviceType", brand, model, "serialNumber", notes, "createdAt", "updatedAt") FROM stdin;
62599ae7-79b9-4e31-b990-8b336942c02c	718e677f-4330-4624-8570-0c32c6247fec	Phone	Generic	Model X	\N	\N	2025-12-15 08:53:33.728	2025-12-15 08:53:33.728
5c727b89-b8d1-41dc-9326-c75613b58c3e	633f2201-429b-4677-99fa-f4ce1a9c4f54	Phone	Generic	Model X	\N	\N	2025-12-15 08:53:33.73	2025-12-15 08:53:33.73
86c1df5e-95ec-4e0a-b8e1-8a9a891ff173	326ce782-c036-4573-a8dc-7c6e9b0f19ea	laptop	Asus	ROG 5	\N	Tak boleh on dan keyboard rosak tit title	2025-12-15 08:59:05.82	2025-12-15 08:59:05.82
9da3b76b-8f90-489e-92ce-fb8e3ba84676	326ce782-c036-4573-a8dc-7c6e9b0f19ea	desktop	Acer	Expire 14	\N	PC tak on ada bau benda terbakar	2025-12-15 08:59:05.824	2025-12-15 08:59:05.824
6edba87d-9b05-4b4b-b9d3-1cf6a9ecd408	326ce782-c036-4573-a8dc-7c6e9b0f19ea	printer	HP	Laserjet 2009	\N	Tak tahi kertas dengan print tak cantik	2025-12-15 08:59:05.827	2025-12-15 08:59:05.827
588a56c1-0dfe-44b0-925f-4b9446a06b37	326ce782-c036-4573-a8dc-7c6e9b0f19ea	monitor	Hp	Gg14	\N	Tak menyala bila on kan AC	2025-12-15 08:59:05.83	2025-12-15 08:59:05.83
89582f1b-7cba-419f-98bc-ebf6bf88d66c	326ce782-c036-4573-a8dc-7c6e9b0f19ea	phone	Asus	ROG phone 5	\N	Bila main game cepat panas dan autoribut	2025-12-15 08:59:05.833	2025-12-15 08:59:05.833
\.


--
-- Data for Name: Job; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Job" (id, "customerId", "deviceId", title, description, status, priority, "quotedAmount", "approvedAmount", diagnosis, "dueDate", "qrToken", "qrExpiresAt", "createdAt", "updatedAt", "assignedAt", "ownerUserId") FROM stdin;
bc85c068-cc97-4c9e-976e-63be1e7eac61	326ce782-c036-4573-a8dc-7c6e9b0f19ea	588a56c1-0dfe-44b0-925f-4b9446a06b37	monitor Hp Gg14 - Yazid	Tak menyala bila on kan AC	APPROVED	NORMAL	\N	\N	\N	2025-12-15 13:49:00	576b4b7e-ac08-45b8-ad40-93f09161a2b4	2026-01-14 08:59:05.831	2025-12-15 08:59:05.831	2025-12-15 14:02:17.893	\N	\N
72ac1407-f466-4e75-a9d1-a48cfdee30fa	326ce782-c036-4573-a8dc-7c6e9b0f19ea	6edba87d-9b05-4b4b-b9d3-1cf6a9ecd408	printer HP Laserjet 2009 - Yazid	Tak tahi kertas dengan print tak cantik	APPROVED	NORMAL	\N	\N	\N	\N	e925a6d6-2e35-40ec-aa1f-9f787c4c3466	2026-01-14 08:59:05.828	2025-12-15 08:59:05.829	2025-12-16 14:46:58.045	\N	\N
41362576-118f-4627-bfcb-60f17f5e8ce0	326ce782-c036-4573-a8dc-7c6e9b0f19ea	86c1df5e-95ec-4e0a-b8e1-8a9a891ff173	laptop Asus ROG 5 - Yazid	Tak boleh on dan keyboard rosak tit title	QUOTATION_SENT	NORMAL	\N	\N	\N	\N	1ed6a95e-d3d6-438e-90af-6a25d1bda64d	2026-01-14 08:59:05.821	2025-12-15 08:59:05.822	2025-12-16 15:58:36.225	2025-12-16 15:58:36.223	\N
cedc72be-cc67-4140-8f38-65e11d581078	326ce782-c036-4573-a8dc-7c6e9b0f19ea	89582f1b-7cba-419f-98bc-ebf6bf88d66c	phone Asus ROG phone 5 - Yazid	Bila main game cepat panas dan autoribut	QUOTATION_SENT	NORMAL	\N	\N	\N	\N	2ca7e5f6-8ed1-4b86-9f20-72c2bb8ddd4e	2026-01-14 08:59:05.833	2025-12-15 08:59:05.834	2025-12-16 16:02:40.307	2025-12-16 16:02:40.306	\N
efe311a1-26d8-4b65-86ef-2b598cd2020c	326ce782-c036-4573-a8dc-7c6e9b0f19ea	9da3b76b-8f90-489e-92ce-fb8e3ba84676	desktop Acer Expire 14 - Yazid	PC tak on ada bau benda terbakar	QUOTATION_SENT	NORMAL	\N	\N	\N	\N	f7563534-7ea2-48f6-aee5-2b9e3833d5a5	2026-01-14 08:59:05.825	2025-12-15 08:59:05.826	2025-12-16 16:29:14.719	2025-12-16 16:29:14.715	\N
\.


--
-- Data for Name: JobMessage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."JobMessage" (id, "jobId", role, content, "createdAt") FROM stdin;
\.


--
-- Data for Name: JobPhoto; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."JobPhoto" (id, "jobId", label, "filePath", "createdAt") FROM stdin;
\.


--
-- Data for Name: JobStatusHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."JobStatusHistory" (id, "jobId", status, notes, "createdAt") FROM stdin;
fdcc1a98-7b9f-4d76-8427-ac6a7e9e36d0	bc85c068-cc97-4c9e-976e-63be1e7eac61	AWAITING_QUOTE	\N	2025-12-15 13:49:57.112
6212b5e8-aaf9-421b-9f86-4c0df6904068	bc85c068-cc97-4c9e-976e-63be1e7eac61	APPROVED	Status updated from AWAITING_QUOTE to APPROVED	2025-12-15 14:02:17.895
e2eb56bd-3cc2-4ffc-813f-ae76a5653dc0	cedc72be-cc67-4140-8f38-65e11d581078	REPAIRING	Status updated from APPROVED to REPAIRING	2025-12-15 14:12:47.219
b0c7fa4d-e17d-4a6f-9e86-98ca845062c8	72ac1407-f466-4e75-a9d1-a48cfdee30fa	APPROVED	Status updated from AWAITING_QUOTE to APPROVED	2025-12-16 14:46:58.048
07cea6e2-3252-4118-87b0-6c2b2d1bc93c	efe311a1-26d8-4b65-86ef-2b598cd2020c	APPROVED	Status updated from AWAITING_QUOTE to APPROVED	2025-12-16 15:36:04.17
ddaac5ff-866a-4af2-ad1e-1242bf6ddbed	41362576-118f-4627-bfcb-60f17f5e8ce0	QUOTATION_SENT	Status updated from AWAITING_QUOTE to QUOTATION_SENT	2025-12-16 15:58:36.227
7cee2459-e471-412a-a202-044ea1952efb	efe311a1-26d8-4b65-86ef-2b598cd2020c	AWAITING_QUOTE	Status updated from APPROVED to AWAITING_QUOTE	2025-12-16 16:00:45.579
0a95f610-4c73-4cdf-9ab8-9e539cb15ffd	cedc72be-cc67-4140-8f38-65e11d581078	AWAITING_QUOTE	Status updated from REPAIRING to AWAITING_QUOTE	2025-12-16 16:00:53.407
04428363-fc7d-49ae-a640-9124de80318b	cedc72be-cc67-4140-8f38-65e11d581078	QUOTATION_SENT	Status updated from AWAITING_QUOTE to QUOTATION_SENT	2025-12-16 16:02:40.309
0bd77e6c-e59b-42b9-8396-e6f988ad3e48	efe311a1-26d8-4b65-86ef-2b598cd2020c	QUOTATION_SENT	Status updated from AWAITING_QUOTE to QUOTATION_SENT	2025-12-16 16:29:14.724
\.


--
-- Data for Name: Message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Message" (id, "customerId", direction, content, status, "sentAt", "receivedAt", "readAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: RefreshToken; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RefreshToken" (id, "tokenHash", "userId", "sessionId", "createdAt", "expiresAt", "revokedAt") FROM stdin;
e60960d9-e7b5-4574-995a-605a79a55c25	$2a$10$QhcmInSGsapEexaRDtgkOusNslZx8Ecd3Q4FoTAcUeEBfHrXdQshW	6225f1a1-3c8a-4d83-81b3-f5ee7c56de38	95e44b88-243e-48c7-9c03-6e49fd4949d2	2025-12-16 12:48:57.145	2025-12-23 12:48:57.144	2025-12-16 14:32:02.598
dc21013b-d25d-44b5-8638-c2e2dda06099	$2a$10$60pO.uJHbWIFmaV6/GX0Beu9r1apZP2VgDB3t9fLU8E25C3cwUF1S	4f8901c8-7550-4b2c-aeed-945c1a0366bf	771466d0-8184-45cc-a683-f4b9406d35fa	2025-12-16 14:45:41.61	2025-12-23 14:45:41.609	2025-12-16 14:47:29.259
90230adf-f3fe-48c5-be51-bf242a59d0ae	$2a$10$Um/0vMqmrdIJ3b0c2SN/LOOx632xsB2Gvq89sdu59ZEtqJw60SCVC	6225f1a1-3c8a-4d83-81b3-f5ee7c56de38	7995d9c1-9df5-4a4b-9cbc-f05a8a51050a	2025-12-16 14:47:39.193	2025-12-23 14:47:39.192	2025-12-16 15:12:37.135
cee79613-dfa9-4668-bfdf-3c50e8b0a284	$2a$10$wIa9n5wUVnOZ.j9fQnd6EOSj3rq5mg2b2z6gE7XVByab24Zkt6b.i	4f8901c8-7550-4b2c-aeed-945c1a0366bf	6e616487-aa99-47a1-b67b-f64166e6f564	2025-12-16 15:12:50.99	2025-12-23 15:12:50.989	2025-12-16 15:44:25.036
b231a9df-5e71-45b2-b970-862f59aee650	$2a$10$LJR.qtynS5odsx0TCukMBu8iLfGdOXYRy3E5Z8AZemHHFzdpGw7Fu	6225f1a1-3c8a-4d83-81b3-f5ee7c56de38	d81c5b2c-63a7-4798-8dc1-0032d20a0977	2025-12-16 15:44:42.655	2025-12-23 15:44:42.654	2025-12-16 15:57:22.011
2946f34d-c90f-4a0b-bc5f-6d5c7fd03371	$2a$10$Y0tnC0VcpHnScaAn6IdHZu2DIFtMLrdNeqDvEncZpF0eOGTisBRpy	4f8901c8-7550-4b2c-aeed-945c1a0366bf	e88b24bd-a685-4921-93b5-ba8e92026262	2025-12-16 15:57:37.43	2025-12-23 15:57:37.429	2025-12-16 15:59:08.557
c21b5ad9-c021-41ab-94cf-7ae2e1eab14f	$2a$10$MVXPbajCBkthEUnrHm2nDOSzOhKhne/GodFbrk7AfmgPT9VbrmTma	6225f1a1-3c8a-4d83-81b3-f5ee7c56de38	a7e46944-0658-413b-a48d-7c0c550e8a4f	2025-12-16 16:00:04.738	2025-12-23 16:00:04.737	2025-12-16 16:01:46.094
cb09d9b4-757f-4e4f-8d5c-167bdf84b599	$2a$10$Ltp3RzOSBjUmajigFhsA/eWhBu/jYFX1h3DHnAen7nYd2OpHc4lu2	4f8901c8-7550-4b2c-aeed-945c1a0366bf	6aea43fc-c561-46c3-9885-245fac9e60b6	2025-12-16 16:02:00.733	2025-12-23 16:02:00.732	2025-12-16 16:29:32.241
e3789929-5e47-4bc0-b5fe-e046004add9c	$2a$10$jl/E1/kbQsNYmQDRYRQP6eEM4XAhonshD2.d9u4.7oVAszKOSB0aW	6225f1a1-3c8a-4d83-81b3-f5ee7c56de38	93f2bec7-b0b8-44ab-b1b2-da96a687cd6f	2025-12-16 12:47:42.707	2025-12-23 12:47:42.706	\N
061b2347-c7f3-41b9-bf2c-76011d03bbfd	$2a$10$8.3hrJaWe4uVl87DP8ZN4uOZ3z868ipVRp4avoRfEgBgKjDedQIiK	6225f1a1-3c8a-4d83-81b3-f5ee7c56de38	dd1de1f4-67b4-47a0-a1a7-1e2810fdffc2	2025-12-16 13:55:23.33	2025-12-23 13:55:23.329	\N
3b1d947f-1d40-42a8-8980-bcbf20465592	$2a$10$O9d57MT1Rp65t4rfoBF86OalK09JdtmnFuHUIhcyEpeyWxeFzNmh.	6225f1a1-3c8a-4d83-81b3-f5ee7c56de38	8b621e1b-c322-463c-b995-fded773a0067	2025-12-16 13:56:51.293	2025-12-23 13:56:51.292	\N
7305b231-e501-4048-a8e6-d4499e7a3b2f	$2a$10$DiW3ygkESn3vTEp4XP5wpOaboRdhCIKfBrjJ13fAeVvuG1LJCvUtG	6225f1a1-3c8a-4d83-81b3-f5ee7c56de38	4c7935b8-1856-44b9-a56d-da6c65fe5ab2	2025-12-16 14:03:15.045	2025-12-23 14:03:15.044	\N
\.


--
-- Data for Name: Reminder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Reminder" (id, "jobId", kind, "sentAt") FROM stdin;
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Session" (id, "userId", "userAgent", "ipAddress", "createdAt", "expiresAt", "revokedAt") FROM stdin;
7995d9c1-9df5-4a4b-9cbc-f05a8a51050a	6225f1a1-3c8a-4d83-81b3-f5ee7c56de38	\N	\N	2025-12-16 14:47:39.088	2025-12-23 14:47:39.088	2025-12-16 15:12:37.11
6e616487-aa99-47a1-b67b-f64166e6f564	4f8901c8-7550-4b2c-aeed-945c1a0366bf	\N	\N	2025-12-16 15:12:50.81	2025-12-23 15:12:50.809	2025-12-16 15:44:25.032
d81c5b2c-63a7-4798-8dc1-0032d20a0977	6225f1a1-3c8a-4d83-81b3-f5ee7c56de38	\N	\N	2025-12-16 15:44:42.502	2025-12-23 15:44:42.501	2025-12-16 15:57:22.008
e88b24bd-a685-4921-93b5-ba8e92026262	4f8901c8-7550-4b2c-aeed-945c1a0366bf	\N	\N	2025-12-16 15:57:37.311	2025-12-23 15:57:37.31	2025-12-16 15:59:08.49
a7e46944-0658-413b-a48d-7c0c550e8a4f	6225f1a1-3c8a-4d83-81b3-f5ee7c56de38	\N	\N	2025-12-16 16:00:04.138	2025-12-23 16:00:04.137	2025-12-16 16:01:46.092
6aea43fc-c561-46c3-9885-245fac9e60b6	4f8901c8-7550-4b2c-aeed-945c1a0366bf	\N	\N	2025-12-16 16:02:00.63	2025-12-23 16:02:00.629	2025-12-16 16:29:32.236
93f2bec7-b0b8-44ab-b1b2-da96a687cd6f	6225f1a1-3c8a-4d83-81b3-f5ee7c56de38	\N	\N	2025-12-16 12:47:42.611	2025-12-23 12:47:42.61	\N
dd1de1f4-67b4-47a0-a1a7-1e2810fdffc2	6225f1a1-3c8a-4d83-81b3-f5ee7c56de38	\N	\N	2025-12-16 13:55:23.222	2025-12-23 13:55:23.221	\N
8b621e1b-c322-463c-b995-fded773a0067	6225f1a1-3c8a-4d83-81b3-f5ee7c56de38	\N	\N	2025-12-16 13:56:51.196	2025-12-23 13:56:51.195	\N
4c7935b8-1856-44b9-a56d-da6c65fe5ab2	6225f1a1-3c8a-4d83-81b3-f5ee7c56de38	\N	\N	2025-12-16 14:03:14.938	2025-12-23 14:03:14.937	\N
95e44b88-243e-48c7-9c03-6e49fd4949d2	6225f1a1-3c8a-4d83-81b3-f5ee7c56de38	\N	\N	2025-12-16 12:48:57.042	2025-12-23 12:48:57.041	2025-12-16 14:32:02.574
771466d0-8184-45cc-a683-f4b9406d35fa	4f8901c8-7550-4b2c-aeed-945c1a0366bf	\N	\N	2025-12-16 14:45:41.505	2025-12-23 14:45:41.504	2025-12-16 14:47:29.257
\.


--
-- Data for Name: SystemSetting; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SystemSetting" (id, key, "group", value, "updatedById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, name, email, "passwordHash", role, "createdAt", "updatedAt", "approvedAt", "approvedBy", "isActive", "lastLoginAt", permissions, status, username) FROM stdin;
6225f1a1-3c8a-4d83-81b3-f5ee7c56de38	Admin	admin@example.com	$2b$10$7jZXUAfFGnaEjvVu5wtxS.Xu/mo/nak5WGo7bbClnWB5a5bcIZn9C	ADMIN	2025-12-16 12:47:39.071	2025-12-16 14:18:50.594	\N	\N	t	\N	\N	ACTIVE	admin
4f8901c8-7550-4b2c-aeed-945c1a0366bf	mohd noryazid	yazidmohd058@gmail.com	$2a$10$9114EoCLej6X4H4gM5oRWOVdHB25Ov5RJtYZmdfmqaxegLVivrLWq	USER	2025-12-16 14:31:49.235	2025-12-16 14:31:49.235	2025-12-16 14:31:49.233	\N	t	\N	\N	ACTIVE	yazid
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
141a1685-d678-4144-9a08-115f4966af5a	841df6f8e27762f8ffb9bc850b058301a8124559407ef75a99445d5fe6f7dad1	2025-12-15 16:28:31.246216+08	20251126071209_whats_appbot	\N	\N	2025-12-15 16:28:31.222099+08	1
8cc2c2f6-25ac-47f5-a632-cac405f82339	b2abf5242016dce6bf3d6a4a71a5a61617e11b644be8635b995e7e86608e3248	2025-12-15 16:28:31.259546+08	20251126081020_add_campaigns_and_settings	\N	\N	2025-12-15 16:28:31.246839+08	1
cef35f04-a104-4965-85a3-df60e554d34e	cdcc99f277ee51be1e2a1fc6359ca361fe07d7be5fdf1c84e437b6115e84aeae	2025-12-15 16:28:31.265701+08	20251213082532_	\N	\N	2025-12-15 16:28:31.260292+08	1
a3a6095f-032a-4008-a46c-c5df70866748	f3fa6219bbac4fc0df29c917b68c43ef4b10205e131bafaf050c4d514c66f0f6	2025-12-15 16:28:31.268173+08	20251215141922_add_job_ownership	\N	\N	2025-12-15 16:28:31.266443+08	1
\.


--
-- Name: AiConversation AiConversation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AiConversation"
    ADD CONSTRAINT "AiConversation_pkey" PRIMARY KEY (id);


--
-- Name: AiMessage AiMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AiMessage"
    ADD CONSTRAINT "AiMessage_pkey" PRIMARY KEY (id);


--
-- Name: CampaignEvent CampaignEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignEvent"
    ADD CONSTRAINT "CampaignEvent_pkey" PRIMARY KEY (id);


--
-- Name: CampaignPreset CampaignPreset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignPreset"
    ADD CONSTRAINT "CampaignPreset_pkey" PRIMARY KEY (id);


--
-- Name: CampaignRecipient CampaignRecipient_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignRecipient"
    ADD CONSTRAINT "CampaignRecipient_pkey" PRIMARY KEY (id);


--
-- Name: Campaign Campaign_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Campaign"
    ADD CONSTRAINT "Campaign_pkey" PRIMARY KEY (id);


--
-- Name: Customer Customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Customer"
    ADD CONSTRAINT "Customer_pkey" PRIMARY KEY (id);


--
-- Name: DeletedUserAudit DeletedUserAudit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DeletedUserAudit"
    ADD CONSTRAINT "DeletedUserAudit_pkey" PRIMARY KEY (id);


--
-- Name: Device Device_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Device"
    ADD CONSTRAINT "Device_pkey" PRIMARY KEY (id);


--
-- Name: JobMessage JobMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobMessage"
    ADD CONSTRAINT "JobMessage_pkey" PRIMARY KEY (id);


--
-- Name: JobPhoto JobPhoto_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobPhoto"
    ADD CONSTRAINT "JobPhoto_pkey" PRIMARY KEY (id);


--
-- Name: JobStatusHistory JobStatusHistory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobStatusHistory"
    ADD CONSTRAINT "JobStatusHistory_pkey" PRIMARY KEY (id);


--
-- Name: Job Job_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Job"
    ADD CONSTRAINT "Job_pkey" PRIMARY KEY (id);


--
-- Name: Message Message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_pkey" PRIMARY KEY (id);


--
-- Name: RefreshToken RefreshToken_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_pkey" PRIMARY KEY (id);


--
-- Name: Reminder Reminder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Reminder"
    ADD CONSTRAINT "Reminder_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: SystemSetting SystemSetting_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SystemSetting"
    ADD CONSTRAINT "SystemSetting_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: CampaignRecipient_campaignId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "CampaignRecipient_campaignId_createdAt_idx" ON public."CampaignRecipient" USING btree ("campaignId", "createdAt");


--
-- Name: CampaignRecipient_campaignId_phone_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "CampaignRecipient_campaignId_phone_idx" ON public."CampaignRecipient" USING btree ("campaignId", phone);


--
-- Name: CampaignRecipient_campaignId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "CampaignRecipient_campaignId_status_idx" ON public."CampaignRecipient" USING btree ("campaignId", status);


--
-- Name: Campaign_status_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Campaign_status_createdAt_idx" ON public."Campaign" USING btree (status, "createdAt");


--
-- Name: Customer_phone_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Customer_phone_key" ON public."Customer" USING btree (phone);


--
-- Name: DeletedUserAudit_deletedAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "DeletedUserAudit_deletedAt_idx" ON public."DeletedUserAudit" USING btree ("deletedAt");


--
-- Name: DeletedUserAudit_deletedById_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "DeletedUserAudit_deletedById_idx" ON public."DeletedUserAudit" USING btree ("deletedById");


--
-- Name: DeletedUserAudit_originalUserId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "DeletedUserAudit_originalUserId_key" ON public."DeletedUserAudit" USING btree ("originalUserId");


--
-- Name: Job_qrToken_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Job_qrToken_key" ON public."Job" USING btree ("qrToken");


--
-- Name: Message_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Message_createdAt_idx" ON public."Message" USING btree ("createdAt");


--
-- Name: Message_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Message_customerId_idx" ON public."Message" USING btree ("customerId");


--
-- Name: RefreshToken_tokenHash_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "RefreshToken_tokenHash_key" ON public."RefreshToken" USING btree ("tokenHash");


--
-- Name: Reminder_jobId_kind_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Reminder_jobId_kind_idx" ON public."Reminder" USING btree ("jobId", kind);


--
-- Name: SystemSetting_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "SystemSetting_key_key" ON public."SystemSetting" USING btree (key);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "User_isActive_idx" ON public."User" USING btree ("isActive");


--
-- Name: User_role_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "User_role_idx" ON public."User" USING btree (role);


--
-- Name: User_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "User_status_idx" ON public."User" USING btree (status);


--
-- Name: User_username_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_username_key" ON public."User" USING btree (username);


--
-- Name: AiMessage AiMessage_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AiMessage"
    ADD CONSTRAINT "AiMessage_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."AiConversation"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CampaignEvent CampaignEvent_campaignId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignEvent"
    ADD CONSTRAINT "CampaignEvent_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES public."Campaign"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CampaignPreset CampaignPreset_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignPreset"
    ADD CONSTRAINT "CampaignPreset_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CampaignRecipient CampaignRecipient_campaignId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignRecipient"
    ADD CONSTRAINT "CampaignRecipient_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES public."Campaign"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CampaignRecipient CampaignRecipient_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignRecipient"
    ADD CONSTRAINT "CampaignRecipient_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Campaign Campaign_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Campaign"
    ADD CONSTRAINT "Campaign_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: DeletedUserAudit DeletedUserAudit_deletedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DeletedUserAudit"
    ADD CONSTRAINT "DeletedUserAudit_deletedById_fkey" FOREIGN KEY ("deletedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Device Device_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Device"
    ADD CONSTRAINT "Device_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: JobMessage JobMessage_jobId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobMessage"
    ADD CONSTRAINT "JobMessage_jobId_fkey" FOREIGN KEY ("jobId") REFERENCES public."Job"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: JobPhoto JobPhoto_jobId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobPhoto"
    ADD CONSTRAINT "JobPhoto_jobId_fkey" FOREIGN KEY ("jobId") REFERENCES public."Job"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: JobStatusHistory JobStatusHistory_jobId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobStatusHistory"
    ADD CONSTRAINT "JobStatusHistory_jobId_fkey" FOREIGN KEY ("jobId") REFERENCES public."Job"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Job Job_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Job"
    ADD CONSTRAINT "Job_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Job Job_deviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Job"
    ADD CONSTRAINT "Job_deviceId_fkey" FOREIGN KEY ("deviceId") REFERENCES public."Device"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Job Job_ownerUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Job"
    ADD CONSTRAINT "Job_ownerUserId_fkey" FOREIGN KEY ("ownerUserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Message Message_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RefreshToken RefreshToken_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public."Session"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RefreshToken RefreshToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Reminder Reminder_jobId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Reminder"
    ADD CONSTRAINT "Reminder_jobId_fkey" FOREIGN KEY ("jobId") REFERENCES public."Job"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SystemSetting SystemSetting_updatedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SystemSetting"
    ADD CONSTRAINT "SystemSetting_updatedById_fkey" FOREIGN KEY ("updatedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict eb6NW7fqJc8c89LUZtjjCQZazVm5GfS5BBYO82D5Dqpok9TFq6BwcnrcsBvUXri

