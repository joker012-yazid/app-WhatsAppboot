--
-- PostgreSQL database dump
--

\restrict AFChyb4Ox97tQypLM69fjjxESIjqnaI18zvnyqm89krXTOQvglqpKcUTxH5cOho

-- Dumped from database version 17.6 (Debian 17.6-0+deb13u1)
-- Dumped by pg_dump version 17.6 (Debian 17.6-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: CampaignKind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CampaignKind" AS ENUM (
    'PROMOTIONAL',
    'ANNOUNCEMENT',
    'FOLLOW_UP',
    'CUSTOM'
);


--
-- Name: CampaignRecipientStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CampaignRecipientStatus" AS ENUM (
    'PENDING',
    'SCHEDULED',
    'SKIPPED',
    'SENT',
    'DELIVERED',
    'FAILED',
    'CANCELLED'
);


--
-- Name: CampaignStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CampaignStatus" AS ENUM (
    'DRAFT',
    'SCHEDULED',
    'RUNNING',
    'PAUSED',
    'COMPLETED',
    'FAILED',
    'CANCELLED'
);


--
-- Name: CustomerType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CustomerType" AS ENUM (
    'VIP',
    'REGULAR',
    'NEW',
    'PROSPECT'
);


--
-- Name: JobPriority; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."JobPriority" AS ENUM (
    'LOW',
    'NORMAL',
    'HIGH',
    'URGENT'
);


--
-- Name: JobStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."JobStatus" AS ENUM (
    'PENDING',
    'QUOTED',
    'APPROVED',
    'REJECTED',
    'IN_PROGRESS',
    'COMPLETED'
);


--
-- Name: MessageDirection; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MessageDirection" AS ENUM (
    'INBOUND',
    'OUTBOUND'
);


--
-- Name: MessageRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MessageRole" AS ENUM (
    'SYSTEM',
    'USER',
    'ASSISTANT',
    'AGENT'
);


--
-- Name: MessageStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MessageStatus" AS ENUM (
    'SENT',
    'DELIVERED',
    'READ',
    'FAILED',
    'RECEIVED'
);


--
-- Name: ReminderKind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ReminderKind" AS ENUM (
    'QUOTE_DAY_1',
    'QUOTE_DAY_20',
    'QUOTE_DAY_30'
);


--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserRole" AS ENUM (
    'ADMIN',
    'TECHNICIAN',
    'CASHIER',
    'MANAGER'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AiConversation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AiConversation" (
    id text NOT NULL,
    "jobId" text,
    "customerId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: AiMessage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AiMessage" (
    id text NOT NULL,
    "conversationId" text NOT NULL,
    role public."MessageRole" NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Campaign; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Campaign" (
    id text NOT NULL,
    name text NOT NULL,
    kind public."CampaignKind" DEFAULT 'PROMOTIONAL'::public."CampaignKind" NOT NULL,
    status public."CampaignStatus" DEFAULT 'DRAFT'::public."CampaignStatus" NOT NULL,
    message text NOT NULL,
    "mediaUrl" text,
    variables text[] DEFAULT ARRAY[]::text[],
    filters jsonb,
    "scheduledFor" timestamp(3) without time zone,
    "startedAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "targetCount" integer DEFAULT 0 NOT NULL,
    "sentCount" integer DEFAULT 0 NOT NULL,
    "failedCount" integer DEFAULT 0 NOT NULL,
    "dailyLimit" integer DEFAULT 150 NOT NULL,
    "randomDelayMin" integer DEFAULT 30 NOT NULL,
    "randomDelayMax" integer DEFAULT 60 NOT NULL,
    "businessHoursStart" integer,
    "businessHoursEnd" integer,
    "createdById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: CampaignEvent; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CampaignEvent" (
    id text NOT NULL,
    "campaignId" text NOT NULL,
    type text NOT NULL,
    details jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: CampaignPreset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CampaignPreset" (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    filters jsonb NOT NULL,
    "createdById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: CampaignRecipient; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CampaignRecipient" (
    id text NOT NULL,
    "campaignId" text NOT NULL,
    "customerId" text,
    phone text NOT NULL,
    name text,
    status public."CampaignRecipientStatus" DEFAULT 'PENDING'::public."CampaignRecipientStatus" NOT NULL,
    error text,
    attempts integer DEFAULT 0 NOT NULL,
    "lastAttemptAt" timestamp(3) without time zone,
    "sentAt" timestamp(3) without time zone,
    "deliveredAt" timestamp(3) without time zone,
    "readAt" timestamp(3) without time zone,
    "respondedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Customer; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Customer" (
    id text NOT NULL,
    name text NOT NULL,
    phone text NOT NULL,
    email text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    tags text[] DEFAULT ARRAY[]::text[],
    type public."CustomerType" DEFAULT 'REGULAR'::public."CustomerType" NOT NULL
);


--
-- Name: Device; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Device" (
    id text NOT NULL,
    "customerId" text NOT NULL,
    "deviceType" text NOT NULL,
    brand text,
    model text,
    "serialNumber" text,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Job; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Job" (
    id text NOT NULL,
    "customerId" text NOT NULL,
    "deviceId" text NOT NULL,
    title text NOT NULL,
    description text,
    status public."JobStatus" DEFAULT 'PENDING'::public."JobStatus" NOT NULL,
    priority public."JobPriority" DEFAULT 'NORMAL'::public."JobPriority" NOT NULL,
    "quotedAmount" numeric(65,30),
    "approvedAmount" numeric(65,30),
    diagnosis text,
    "dueDate" timestamp(3) without time zone,
    "qrToken" text NOT NULL,
    "qrExpiresAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: JobMessage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."JobMessage" (
    id text NOT NULL,
    "jobId" text NOT NULL,
    role public."MessageRole" NOT NULL,
    content text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: JobPhoto; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."JobPhoto" (
    id text NOT NULL,
    "jobId" text NOT NULL,
    label text,
    "filePath" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: JobStatusHistory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."JobStatusHistory" (
    id text NOT NULL,
    "jobId" text NOT NULL,
    status public."JobStatus" NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Message" (
    id text NOT NULL,
    "customerId" text NOT NULL,
    direction public."MessageDirection" NOT NULL,
    content text NOT NULL,
    status public."MessageStatus" DEFAULT 'SENT'::public."MessageStatus" NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "receivedAt" timestamp(3) without time zone,
    "readAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: RefreshToken; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."RefreshToken" (
    id text NOT NULL,
    "tokenHash" text NOT NULL,
    "userId" text NOT NULL,
    "sessionId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "revokedAt" timestamp(3) without time zone
);


--
-- Name: Reminder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Reminder" (
    id text NOT NULL,
    "jobId" text NOT NULL,
    kind public."ReminderKind" NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "userId" text NOT NULL,
    "userAgent" text,
    "ipAddress" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "revokedAt" timestamp(3) without time zone
);


--
-- Name: SystemSetting; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SystemSetting" (
    id text NOT NULL,
    key text NOT NULL,
    "group" text,
    value jsonb NOT NULL,
    "updatedById" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    role public."UserRole" DEFAULT 'TECHNICIAN'::public."UserRole" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: AiConversation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AiConversation" (id, "jobId", "customerId", "createdAt") FROM stdin;
\.


--
-- Data for Name: AiMessage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."AiMessage" (id, "conversationId", role, content, "createdAt") FROM stdin;
\.


--
-- Data for Name: Campaign; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Campaign" (id, name, kind, status, message, "mediaUrl", variables, filters, "scheduledFor", "startedAt", "completedAt", "targetCount", "sentCount", "failedCount", "dailyLimit", "randomDelayMin", "randomDelayMax", "businessHoursStart", "businessHoursEnd", "createdById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CampaignEvent; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CampaignEvent" (id, "campaignId", type, details, "createdAt") FROM stdin;
\.


--
-- Data for Name: CampaignPreset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CampaignPreset" (id, name, description, filters, "createdById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: CampaignRecipient; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."CampaignRecipient" (id, "campaignId", "customerId", phone, name, status, error, attempts, "lastAttemptAt", "sentAt", "deliveredAt", "readAt", "respondedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Customer; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Customer" (id, name, phone, email, notes, "createdAt", "updatedAt", tags, type) FROM stdin;
bfbb5b73-7d72-45c7-a81e-9ee988739600	Ali Ahmad	60110000001	ali@example.com	VIP	2025-12-13 08:47:58.768	2025-12-13 08:47:58.768	{}	REGULAR
c32c3ad0-e950-478a-b1eb-3213e0965bea	Siti Nor	60110000002	siti@example.com	\N	2025-12-13 08:47:58.77	2025-12-13 08:47:58.77	{}	REGULAR
5105e0aa-abbb-4ed9-8cfb-7d49f1270925	Rahman Co	60110000003	ops@rahmanco.my	Corporate	2025-12-13 08:47:58.771	2025-12-13 08:47:58.771	{}	REGULAR
5237f33b-bcf3-4e0c-b8ef-989e00f6e574	Farah Aziz	60110000004	\N	Prefers WhatsApp	2025-12-13 08:47:58.772	2025-12-13 08:47:58.772	{}	REGULAR
db90630c-0401-4faf-b0db-7602abd1962f	Daniel Tan	60110000005	daniel@example.com	\N	2025-12-13 08:47:58.774	2025-12-13 08:47:58.774	{}	REGULAR
2fa5cda7-70ed-48e4-837a-011dba608a53	Yazid	0163182443	yazidmohd058@gmail.com	\N	2025-12-13 08:53:19.657	2025-12-13 08:53:19.657	{WALK-IN,QR-REGISTERED}	REGULAR
\.


--
-- Data for Name: Device; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Device" (id, "customerId", "deviceType", brand, model, "serialNumber", notes, "createdAt", "updatedAt") FROM stdin;
b825ff62-8932-46db-8183-04d8fb16e514	bfbb5b73-7d72-45c7-a81e-9ee988739600	Phone	Generic	Model X	\N	\N	2025-12-13 08:47:58.778	2025-12-13 08:47:58.778
2310bd99-5a13-4a34-bc84-d0eec73293aa	c32c3ad0-e950-478a-b1eb-3213e0965bea	Phone	Generic	Model X	\N	\N	2025-12-13 08:47:58.78	2025-12-13 08:47:58.78
33feef02-6e3c-4f33-b064-2e63e0421e58	2fa5cda7-70ed-48e4-837a-011dba608a53	printer	Hp	Laserjet 2008	\N	Tak boleh nak print kertas sangkut	2025-12-13 08:53:19.659	2025-12-13 08:53:19.659
\.


--
-- Data for Name: Job; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Job" (id, "customerId", "deviceId", title, description, status, priority, "quotedAmount", "approvedAmount", diagnosis, "dueDate", "qrToken", "qrExpiresAt", "createdAt", "updatedAt") FROM stdin;
483707a4-df20-4039-9f84-53d80fdb6f2d	2fa5cda7-70ed-48e4-837a-011dba608a53	33feef02-6e3c-4f33-b064-2e63e0421e58	printer Hp Laserjet 2008 - Yazid	Tak boleh nak print kertas sangkut	PENDING	NORMAL	\N	\N	\N	\N	7379d76e-f071-4b1b-b642-80e03cbaadac	2025-12-20 09:02:23.618	2025-12-13 08:53:19.662	2025-12-13 09:02:23.619
\.


--
-- Data for Name: JobMessage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."JobMessage" (id, "jobId", role, content, "createdAt") FROM stdin;
\.


--
-- Data for Name: JobPhoto; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."JobPhoto" (id, "jobId", label, "filePath", "createdAt") FROM stdin;
\.


--
-- Data for Name: JobStatusHistory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."JobStatusHistory" (id, "jobId", status, notes, "createdAt") FROM stdin;
\.


--
-- Data for Name: Message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Message" (id, "customerId", direction, content, status, "sentAt", "receivedAt", "readAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: RefreshToken; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."RefreshToken" (id, "tokenHash", "userId", "sessionId", "createdAt", "expiresAt", "revokedAt") FROM stdin;
f939187f-8b54-4f9c-8cab-5ced6273473a	$2a$10$BeRgt0cnvr7tW1Dw0pcQ4Oz9jpdvclo8oIO7jHOQINmAMzq/K9qWC	f8a39d6d-5c61-48ef-88cb-e01bf65a44c8	6dc53ab5-7c14-442c-a94e-ee519f931b7c	2025-12-13 08:48:45.4	2025-12-20 08:48:45.399	\N
2cada819-b8a1-4611-a3af-e57253fe4e11	$2a$10$lEF9ttRAdD18sCXRjoGFhuPkqvohYlg7MOj9vBlxQacikljWpJ4Qu	f8a39d6d-5c61-48ef-88cb-e01bf65a44c8	a81fcc98-d962-446c-88ff-d9a18d91f378	2025-12-13 08:50:20.322	2025-12-20 08:50:20.321	\N
5f656f35-865b-4bb5-b963-f411a83545d6	$2a$10$srLu0Jc9AtGVjHhhLAvWDuOT0b9Z3cv00UTQ2sZde5i06I7O0hJye	f8a39d6d-5c61-48ef-88cb-e01bf65a44c8	599c2b24-96d1-4733-9d10-5cabc11f5ee3	2025-12-13 08:51:03.956	2025-12-20 08:51:03.955	\N
89854d93-0130-44f7-8121-5a8fe08c4b8a	$2a$10$F5OVMomOK2ox3PQRG1r7peI4KOKz3sR9r12b6SCKb59M2MdR28FrS	f8a39d6d-5c61-48ef-88cb-e01bf65a44c8	fac1e470-23ab-4e9e-a869-386d76b0bb9d	2025-12-13 09:19:32.303	2025-12-20 09:19:32.302	\N
fdcf6baa-2591-4a48-a43b-70a12982d059	$2a$10$ZLREY.DSpAA3j4gnq8fGj.fxOMk9logLRUjQY2U2WWluB/g63gM1u	f8a39d6d-5c61-48ef-88cb-e01bf65a44c8	67c175be-4389-4010-b074-37b3e0d77593	2025-12-13 10:24:05.359	2025-12-20 10:24:05.358	\N
\.


--
-- Data for Name: Reminder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Reminder" (id, "jobId", kind, "sentAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Session" (id, "userId", "userAgent", "ipAddress", "createdAt", "expiresAt", "revokedAt") FROM stdin;
6dc53ab5-7c14-442c-a94e-ee519f931b7c	f8a39d6d-5c61-48ef-88cb-e01bf65a44c8	\N	\N	2025-12-13 08:48:45.289	2025-12-20 08:48:45.288	\N
a81fcc98-d962-446c-88ff-d9a18d91f378	f8a39d6d-5c61-48ef-88cb-e01bf65a44c8	\N	\N	2025-12-13 08:50:20.222	2025-12-20 08:50:20.221	\N
599c2b24-96d1-4733-9d10-5cabc11f5ee3	f8a39d6d-5c61-48ef-88cb-e01bf65a44c8	\N	\N	2025-12-13 08:51:03.827	2025-12-20 08:51:03.826	\N
fac1e470-23ab-4e9e-a869-386d76b0bb9d	f8a39d6d-5c61-48ef-88cb-e01bf65a44c8	\N	\N	2025-12-13 09:19:32.206	2025-12-20 09:19:32.205	\N
67c175be-4389-4010-b074-37b3e0d77593	f8a39d6d-5c61-48ef-88cb-e01bf65a44c8	\N	\N	2025-12-13 10:24:05.253	2025-12-20 10:24:05.252	\N
\.


--
-- Data for Name: SystemSetting; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SystemSetting" (id, key, "group", value, "updatedById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, name, email, "passwordHash", role, "createdAt", "updatedAt") FROM stdin;
f8a39d6d-5c61-48ef-88cb-e01bf65a44c8	Admin	admin@example.com	$2a$10$o3npgCC4Ad.HEpwL6jh1xuKIx56eCoaX2GzcgW.UpXl5VUR4V53he	ADMIN	2025-12-13 08:47:58.76	2025-12-13 08:47:58.76
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
8279299b-d352-4d09-ad7c-be7c24ea2e1c	841df6f8e27762f8ffb9bc850b058301a8124559407ef75a99445d5fe6f7dad1	2025-12-13 16:21:19.863549+08	20251126071209_whats_appbot	\N	\N	2025-12-13 16:21:19.84107+08	1
c13f2ab6-cda6-4777-bd87-a3cb2a4aeeff	b2abf5242016dce6bf3d6a4a71a5a61617e11b644be8635b995e7e86608e3248	2025-12-13 16:21:19.883878+08	20251126081020_add_campaigns_and_settings	\N	\N	2025-12-13 16:21:19.864089+08	1
1d0ee2d2-199a-4853-ae79-0642c1c7384b	cdcc99f277ee51be1e2a1fc6359ca361fe07d7be5fdf1c84e437b6115e84aeae	2025-12-13 16:25:32.218066+08	20251213082532_	\N	\N	2025-12-13 16:25:32.211169+08	1
\.


--
-- Name: AiConversation AiConversation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AiConversation"
    ADD CONSTRAINT "AiConversation_pkey" PRIMARY KEY (id);


--
-- Name: AiMessage AiMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AiMessage"
    ADD CONSTRAINT "AiMessage_pkey" PRIMARY KEY (id);


--
-- Name: CampaignEvent CampaignEvent_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignEvent"
    ADD CONSTRAINT "CampaignEvent_pkey" PRIMARY KEY (id);


--
-- Name: CampaignPreset CampaignPreset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignPreset"
    ADD CONSTRAINT "CampaignPreset_pkey" PRIMARY KEY (id);


--
-- Name: CampaignRecipient CampaignRecipient_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignRecipient"
    ADD CONSTRAINT "CampaignRecipient_pkey" PRIMARY KEY (id);


--
-- Name: Campaign Campaign_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Campaign"
    ADD CONSTRAINT "Campaign_pkey" PRIMARY KEY (id);


--
-- Name: Customer Customer_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Customer"
    ADD CONSTRAINT "Customer_pkey" PRIMARY KEY (id);


--
-- Name: Device Device_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Device"
    ADD CONSTRAINT "Device_pkey" PRIMARY KEY (id);


--
-- Name: JobMessage JobMessage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobMessage"
    ADD CONSTRAINT "JobMessage_pkey" PRIMARY KEY (id);


--
-- Name: JobPhoto JobPhoto_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobPhoto"
    ADD CONSTRAINT "JobPhoto_pkey" PRIMARY KEY (id);


--
-- Name: JobStatusHistory JobStatusHistory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobStatusHistory"
    ADD CONSTRAINT "JobStatusHistory_pkey" PRIMARY KEY (id);


--
-- Name: Job Job_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Job"
    ADD CONSTRAINT "Job_pkey" PRIMARY KEY (id);


--
-- Name: Message Message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_pkey" PRIMARY KEY (id);


--
-- Name: RefreshToken RefreshToken_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_pkey" PRIMARY KEY (id);


--
-- Name: Reminder Reminder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Reminder"
    ADD CONSTRAINT "Reminder_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: SystemSetting SystemSetting_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SystemSetting"
    ADD CONSTRAINT "SystemSetting_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Customer_phone_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Customer_phone_key" ON public."Customer" USING btree (phone);


--
-- Name: Job_qrToken_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Job_qrToken_key" ON public."Job" USING btree ("qrToken");


--
-- Name: Message_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Message_createdAt_idx" ON public."Message" USING btree ("createdAt");


--
-- Name: Message_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Message_customerId_idx" ON public."Message" USING btree ("customerId");


--
-- Name: RefreshToken_tokenHash_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "RefreshToken_tokenHash_key" ON public."RefreshToken" USING btree ("tokenHash");


--
-- Name: Reminder_jobId_kind_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Reminder_jobId_kind_idx" ON public."Reminder" USING btree ("jobId", kind);


--
-- Name: SystemSetting_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "SystemSetting_key_key" ON public."SystemSetting" USING btree (key);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: AiMessage AiMessage_conversationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AiMessage"
    ADD CONSTRAINT "AiMessage_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES public."AiConversation"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CampaignEvent CampaignEvent_campaignId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignEvent"
    ADD CONSTRAINT "CampaignEvent_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES public."Campaign"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CampaignPreset CampaignPreset_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignPreset"
    ADD CONSTRAINT "CampaignPreset_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: CampaignRecipient CampaignRecipient_campaignId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignRecipient"
    ADD CONSTRAINT "CampaignRecipient_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES public."Campaign"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CampaignRecipient CampaignRecipient_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CampaignRecipient"
    ADD CONSTRAINT "CampaignRecipient_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Campaign Campaign_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Campaign"
    ADD CONSTRAINT "Campaign_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Device Device_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Device"
    ADD CONSTRAINT "Device_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: JobMessage JobMessage_jobId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobMessage"
    ADD CONSTRAINT "JobMessage_jobId_fkey" FOREIGN KEY ("jobId") REFERENCES public."Job"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: JobPhoto JobPhoto_jobId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobPhoto"
    ADD CONSTRAINT "JobPhoto_jobId_fkey" FOREIGN KEY ("jobId") REFERENCES public."Job"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: JobStatusHistory JobStatusHistory_jobId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."JobStatusHistory"
    ADD CONSTRAINT "JobStatusHistory_jobId_fkey" FOREIGN KEY ("jobId") REFERENCES public."Job"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Job Job_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Job"
    ADD CONSTRAINT "Job_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Job Job_deviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Job"
    ADD CONSTRAINT "Job_deviceId_fkey" FOREIGN KEY ("deviceId") REFERENCES public."Device"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Message Message_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Message"
    ADD CONSTRAINT "Message_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RefreshToken RefreshToken_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public."Session"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RefreshToken RefreshToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Reminder Reminder_jobId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Reminder"
    ADD CONSTRAINT "Reminder_jobId_fkey" FOREIGN KEY ("jobId") REFERENCES public."Job"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SystemSetting SystemSetting_updatedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SystemSetting"
    ADD CONSTRAINT "SystemSetting_updatedById_fkey" FOREIGN KEY ("updatedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict AFChyb4Ox97tQypLM69fjjxESIjqnaI18zvnyqm89krXTOQvglqpKcUTxH5cOho

